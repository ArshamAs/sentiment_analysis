from textblob import TextBlob
from dataclasses import dataclass


@dataclass
class MoodData:
    emoji: str
    sentiment: float


def mood_get(input_text: str, *, threshold: float) -> MoodData:
    sentiment: float = TextBlob(input_text).sentiment.polarity

    friendly_threshold: float = threshold
    hostile_threshold: float = -threshold

    if sentiment >= friendly_threshold:
        return MoodData('😊', sentiment)
    elif sentiment <= hostile_threshold:
        return MoodData('😠', sentiment)
    else:
        return MoodData('😐', sentiment)


if __name__ == '__main__':
    text: str = input('Text: ')
    mood: MoodData = mood_get(text, threshold=0.3)

    print(f'{mood.emoji} ({mood.sentiment})')